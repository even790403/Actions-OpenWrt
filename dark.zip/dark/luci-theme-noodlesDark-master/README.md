# 改个名字而已，自己玩
# A Luci Argon theme for LEDE/OpenWRT
  复制以下主题组合自己使用

  Thanks https://github.com/sypopo/luci-theme-argon-mc
  Thanks https://github.com/jerrykuku/luci-theme-argon
  Thanks https://github.com/Lienol/openwrt-package
  Thanks https://github.com/coolsnowwolf/lede
